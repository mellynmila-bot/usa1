import React, { useState, useEffect } from 'react';
import { Menu, X, MessageCircle } from 'lucide-react';
import { Language } from '../types';
import { translations } from '../data/siteData';

interface NavbarProps {
  currentLang: Language;
  onLanguageChange: (lang: Language) => void;
  onBookClick: (contextMessage?: string) => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentLang,
  onLanguageChange,
  onBookClick
}) => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const t = translations[currentLang];

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { label: t.nav.services, href: '#servicos' },
    { label: t.nav.gallery, href: '#galeria' },
    { label: t.nav.about, href: '#sobre' },
    { label: t.nav.instagram, href: '#instagram' },
    { label: t.nav.reviews, href: '#avaliacoes' },
    { label: t.nav.studio, href: '#studio' },
    { label: t.nav.faq, href: '#faq' }
  ];

  const handleNavClick = (href: string) => {
    setMobileMenuOpen(false);
    const element = document.querySelector(href);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <>
      {/* Skip to Content accessible link */}
      <a
        href="#main-content"
        className="sr-only focus:not-sr-only focus:fixed focus:top-2 focus:left-2 focus:z-50 focus:px-4 focus:py-2 focus:bg-[#2A2C2E] focus:text-white focus:rounded focus:outline-none focus:ring-2 focus:ring-[#B4B8BC]"
      >
        {t.nav.skipToContent}
      </a>

      <header
        className={`fixed top-0 left-0 right-0 z-40 transition-all duration-300 ${
          isScrolled
            ? 'bg-white/95 backdrop-blur-md shadow-sm border-b border-[#B4B8BC]/40 py-3'
            : 'bg-white/80 backdrop-blur-sm py-4 border-b border-transparent'
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between gap-4">
            {/* Brand Logo Lockup */}
            <a
              href="#"
              className="flex flex-col items-start group focus:outline-none focus-visible:ring-2 focus-visible:ring-[#2A2C2E]"
            >
              <span className="font-serif-title text-xl sm:text-2xl font-normal tracking-[0.22em] text-[#2A2C2E] group-hover:text-black transition-colors uppercase">
                NAIELLY
              </span>
              <span className="text-[10px] tracking-[0.3em] uppercase text-[#6A6E72] font-medium flex items-center gap-1.5 -mt-0.5">
                <span className="w-3 h-px bg-[#B4B8BC]" />
                Beauty Center
                <span className="w-3 h-px bg-[#B4B8BC]" />
              </span>
            </a>

            {/* Desktop Navigation Links */}
            <nav className="hidden lg:flex items-center gap-6 xl:gap-8 text-sm font-medium text-[#5F6368]">
              {navLinks.map((link) => (
                <button
                  key={link.href}
                  onClick={() => handleNavClick(link.href)}
                  className="hover:text-[#2A2C2E] transition-colors whitespace-nowrap cursor-pointer hover:underline underline-offset-8 decoration-[#B4B8BC] py-1"
                >
                  {link.label}
                </button>
              ))}
            </nav>

            {/* Right Zone: Language Selector & Booking CTA */}
            <div className="flex items-center gap-2 sm:gap-4">
              {/* Language Switcher Pill */}
              <div
                className="flex items-center p-1 rounded-full bg-[#F1F2F3] border border-[#B4B8BC]/50 shadow-inner"
                role="group"
                aria-label={t.nav.langLabel}
              >
                {(['pt', 'en', 'es'] as Language[]).map((lang) => {
                  const isActive = currentLang === lang;
                  return (
                    <button
                      key={lang}
                      onClick={() => onLanguageChange(lang)}
                      className={`px-2.5 py-1 text-xs font-semibold rounded-full transition-all cursor-pointer ${
                        isActive
                          ? 'bg-white text-[#2A2C2E] shadow-sm border border-[#B4B8BC]/60 font-bold'
                          : 'text-[#6A6E72] hover:text-[#2A2C2E]'
                      }`}
                      aria-pressed={isActive}
                      title={
                        lang === 'pt'
                          ? 'Português'
                          : lang === 'en'
                          ? 'English'
                          : 'Español'
                      }
                    >
                      {lang.toUpperCase()}
                    </button>
                  );
                })}
              </div>

              {/* Header Primary CTA (WhatsApp) */}
              <button
                onClick={() => onBookClick()}
                className="btn-mirror-primary text-xs sm:text-sm px-3.5 sm:px-4 py-2 hidden sm:inline-flex"
                aria-label={t.nav.book}
              >
                <MessageCircle className="w-4 h-4 text-[#2A2C2E]" />
                <span>{t.nav.book}</span>
              </button>

              {/* Mobile Hamburger Button */}
              <button
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                className="lg:hidden p-2 rounded-md text-[#2A2C2E] hover:bg-[#F1F2F3] focus:outline-none focus:ring-2 focus:ring-[#B4B8BC]"
                aria-expanded={mobileMenuOpen}
                aria-label="Abrir menu de navegação"
              >
                {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
              </button>
            </div>
          </div>
        </div>

        {/* Mobile Dropdown Menu */}
        {mobileMenuOpen && (
          <div className="lg:hidden bg-white border-b border-[#B4B8BC]/50 px-6 pt-4 pb-6 shadow-xl animate-fade-in">
            <div className="flex flex-col gap-3">
              {navLinks.map((link) => (
                <button
                  key={link.href}
                  onClick={() => handleNavClick(link.href)}
                  className="text-left text-base font-medium text-[#2A2C2E] py-2 border-b border-[#F1F2F3] hover:text-black hover:pl-1 transition-all"
                >
                  {link.label}
                </button>
              ))}

              <div className="pt-3 flex flex-col gap-2">
                <button
                  onClick={() => {
                    setMobileMenuOpen(false);
                    onBookClick();
                  }}
                  className="btn-mirror-primary w-full py-3 text-sm flex items-center justify-center gap-2"
                >
                  <MessageCircle className="w-4 h-4" />
                  <span>{t.nav.book} (WhatsApp)</span>
                </button>

                <a
                  href="https://naielly-beauty-center.square.site/"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="btn-mirror-secondary w-full py-2.5 text-sm flex items-center justify-center gap-2 text-[#2A2C2E] border-[#8E9296]"
                >
                  <span>Agendamento Online (Square ↗)</span>
                </a>
              </div>
            </div>
          </div>
        )}
      </header>
    </>
  );
};
