import React, { useState } from 'react';
import { Star, Quote, ChevronLeft, ChevronRight, MessageCircle } from 'lucide-react';
import { Language, FeedbackItem } from '../types';
import { translations } from '../data/siteData';

interface FeedbacksSectionProps {
  currentLang: Language;
  onBookClick: (contextMessage?: string) => void;
}

export const FeedbacksSection: React.FC<FeedbacksSectionProps> = ({
  currentLang,
  onBookClick
}) => {
  const [mobileIndex, setMobileIndex] = useState(0);

  const t = translations[currentLang];
  const feedbacks = t.feedbacks;

  const handleNext = () => {
    setMobileIndex((prev) => (prev + 1) % feedbacks.items.length);
  };

  const handlePrev = () => {
    setMobileIndex((prev) => (prev - 1 + feedbacks.items.length) % feedbacks.items.length);
  };

  const handleFeedbackCta = () => {
    let msg = '';
    if (currentLang === 'pt') {
      msg = 'Olá, Naielly! 💛 Li as avaliações no seu site e gostaria de agendar um horário para viver essa experiência!';
    } else if (currentLang === 'en') {
      msg = 'Hello Naielly! 💛 I read the reviews on your website and would love to schedule an appointment to experience this for myself!';
    } else {
      msg = '¡Hola, Naielly! 💛 Leí los testimonios en tu sitio web y me encantaría reservar una cita para vivir esta experiencia!';
    }
    onBookClick(msg);
  };

  return (
    <section id="avaliacoes" className="py-20 md:py-28 bg-[#F1F2F3] relative">
      {/* SVG Defs for Golden Mirror Star Gradient */}
      <svg width="0" height="0" className="absolute pointer-events-none" aria-hidden="true">
        <defs>
          <linearGradient id="goldMirrorStar" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#C69214" />
            <stop offset="22%" stopColor="#FFF7CC" />
            <stop offset="45%" stopColor="#D4AF37" />
            <stop offset="68%" stopColor="#FFFDF0" />
            <stop offset="85%" stopColor="#E5C158" />
            <stop offset="100%" stopColor="#996515" />
          </linearGradient>
        </defs>
      </svg>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-12 sm:mb-14">
          <div className="inline-flex items-center gap-2 mb-3">
            <span className="w-8 h-px bg-[#B4B8BC]" />
            <span className="text-xs uppercase tracking-widest font-semibold text-[#6A6E72]">
              Depoimentos • Client Reviews
            </span>
            <span className="w-8 h-px bg-[#B4B8BC]" />
          </div>
          <h2 className="font-serif-title text-2xl sm:text-3xl md:text-4xl text-[#2A2C2E] mb-4">
            {feedbacks.title}
          </h2>
          <p className="text-sm sm:text-base text-[#5F6368] leading-relaxed">
            {feedbacks.subtitle}
          </p>
        </div>

        {/* Desktop Grid 3x2 */}
        <div className="hidden md:grid md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
          {feedbacks.items.map((item: FeedbackItem) => (
            <div
              key={item.id}
              className="mirror-card p-6 bg-white flex flex-col justify-between transition-all hover:-translate-y-1"
            >
              <div>
                {/* 5 Stars with Shiny Golden Mirror Gradient */}
                <div className="flex items-center gap-1.5 mb-4">
                  {[...Array(item.rating)].map((_, i) => (
                    <Star
                      key={i}
                      className="w-4 h-4 sm:w-5 sm:h-5 filter drop-shadow-[0_1px_2px_rgba(212,175,55,0.45)]"
                      style={{
                        fill: 'url(#goldMirrorStar)',
                        stroke: '#B8860B',
                        strokeWidth: 0.75
                      }}
                    />
                  ))}
                </div>

                <Quote className="w-7 h-7 text-[#B4B8BC]/50 mb-3" />

                <p className="font-serif-title text-base sm:text-lg text-[#2A2C2E] italic leading-relaxed mb-6">
                  {item.quote}
                </p>
              </div>

              <div className="pt-4 border-t border-[#F1F2F3] flex items-center justify-between">
                <div>
                  <h4 className="text-sm font-bold text-[#2A2C2E]">
                    {item.name}
                  </h4>
                  <span className="text-xs text-[#6A6E72]">
                    {item.service}
                  </span>
                </div>
                <span className="text-[10px] uppercase tracking-wider text-[#8E9296] bg-[#F1F2F3] px-2 py-0.5 rounded">
                  Verificado
                </span>
              </div>
            </div>
          ))}
        </div>

        {/* Mobile Carousel with Touch Navigation */}
        <div className="md:hidden mb-10">
          {(() => {
            const currentItem = feedbacks.items[mobileIndex];
            return (
              <div className="mirror-card p-5 bg-white flex flex-col justify-between min-h-[240px]">
                <div>
                  <div className="flex items-center justify-between mb-4">
                    {/* Golden Mirror Stars on Mobile */}
                    <div className="flex items-center gap-1.5">
                      {[...Array(currentItem.rating)].map((_, i) => (
                        <Star
                          key={i}
                          className="w-4 h-4 filter drop-shadow-[0_1px_2px_rgba(212,175,55,0.45)]"
                          style={{
                            fill: 'url(#goldMirrorStar)',
                            stroke: '#B8860B',
                            strokeWidth: 0.75
                          }}
                        />
                      ))}
                    </div>
                    <span className="text-xs font-mono text-[#8E9296]">
                      {mobileIndex + 1} / {feedbacks.items.length}
                    </span>
                  </div>

                  <p className="font-serif-title text-base text-[#2A2C2E] italic leading-relaxed mb-6">
                    {currentItem.quote}
                  </p>
                </div>

                <div className="pt-4 border-t border-[#F1F2F3] flex items-center justify-between">
                  <div>
                    <h4 className="text-sm font-bold text-[#2A2C2E]">
                      {currentItem.name}
                    </h4>
                    <span className="text-xs text-[#6A6E72]">
                      {currentItem.service}
                    </span>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={handlePrev}
                      aria-label="Avaliação anterior"
                      className="p-1.5 rounded-full border border-[#B4B8BC] hover:bg-[#F1F2F3] text-[#2A2C2E] cursor-pointer"
                    >
                      <ChevronLeft className="w-4 h-4" />
                    </button>
                    <button
                      onClick={handleNext}
                      aria-label="Próxima avaliação"
                      className="p-1.5 rounded-full border border-[#B4B8BC] hover:bg-[#F1F2F3] text-[#2A2C2E] cursor-pointer"
                    >
                      <ChevronRight className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            );
          })()}
        </div>

        {/* FTC / Demo disclaimer */}
        <p className="text-center text-xs text-[#6A6E72] max-w-xl mx-auto mb-10 italic">
          {feedbacks.disclaimer}
        </p>

        {/* Section CTA Button */}
        <div className="flex justify-center">
          <button
            onClick={handleFeedbackCta}
            className="btn-mirror-primary text-xs sm:text-base px-8 py-3.5 shadow-md w-full sm:w-auto flex items-center justify-center gap-2 cursor-pointer"
          >
            <MessageCircle className="w-5 h-5" />
            <span>{feedbacks.cta}</span>
          </button>
        </div>
      </div>
    </section>
  );
};
