import React, { useState } from 'react';
import { Clock, MessageCircle } from 'lucide-react';
import { Language, ServiceItem } from '../types';
import { translations } from '../data/siteData';

interface ServicesSectionProps {
  currentLang: Language;
  onBookClick: (contextMessage?: string) => void;
}

export const ServicesSection: React.FC<ServicesSectionProps> = ({
  currentLang,
  onBookClick
}) => {
  const [activeTab, setActiveTab] = useState<'cilios' | 'sobrancelhas' | 'maquiagem' | 'pele' | 'epilacao'>('cilios');

  const t = translations[currentLang];
  const services = t.services;

  const filteredServices = services.items.filter((item: ServiceItem) => item.group === activeTab);

  const tabKeys: Array<'cilios' | 'sobrancelhas' | 'maquiagem' | 'pele' | 'epilacao'> = [
    'cilios',
    'sobrancelhas',
    'maquiagem',
    'pele',
    'epilacao'
  ];

  const handleBookService = (service: ServiceItem) => {
    let msg = '';
    if (currentLang === 'pt') {
      msg = `Olá, Naielly! 💛 Vi o serviço "${service.name}" no site e gostaria de agendar um horário para este procedimento.`;
    } else if (currentLang === 'en') {
      msg = `Hello Naielly! 💛 I saw your "${service.name}" service on your website and would love to book an appointment for it.`;
    } else {
      msg = `¡Hola, Naielly! 💛 Vi el servicio de "${service.name}" en tu sitio web y me gustaría reservar una cita para este procedimiento.`;
    }
    onBookClick(msg);
  };

  return (
    <section id="servicos" className="py-20 md:py-28 bg-[#F1F2F3] relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-12">
          <div className="inline-flex items-center gap-2 mb-3">
            <span className="w-8 h-px bg-[#B4B8BC]" />
            <span className="text-xs uppercase tracking-widest font-semibold text-[#6A6E72]">
              Menu de Serviços • Services
            </span>
            <span className="w-8 h-px bg-[#B4B8BC]" />
          </div>
          <h2 className="font-serif-title text-3xl sm:text-4xl md:text-4xl text-[#2A2C2E] mb-4">
            {services.title}
          </h2>
          <p className="text-base text-[#5F6368] leading-relaxed">
            {services.subtitle}
          </p>
        </div>

        {/* Category Tabs */}
        <div className="flex items-center justify-center mb-10 overflow-x-auto pb-2 scrollbar-none">
          <div className="inline-flex p-1.5 rounded-full bg-white border border-[#B4B8BC]/50 shadow-sm gap-1">
            {tabKeys.map((key) => {
              const isActive = activeTab === key;
              return (
                <button
                  key={key}
                  onClick={() => setActiveTab(key)}
                  className={`px-4 sm:px-5 py-2 rounded-full text-xs sm:text-sm font-medium transition-all whitespace-nowrap cursor-pointer ${
                    isActive
                      ? 'bg-mirror text-[#2A2C2E] shadow-sm font-semibold'
                      : 'text-[#5F6368] hover:text-[#2A2C2E] hover:bg-[#F1F2F3]/60'
                  }`}
                  aria-pressed={isActive}
                >
                  {services.categories[key]}
                </button>
              );
            })}
          </div>
        </div>

        {/* Services Grid (2 columns on desktop, 1 on mobile) */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-12">
          {filteredServices.map((service: ServiceItem) => (
            <div
              key={service.id}
              className="mirror-card p-5 sm:p-6 flex flex-col sm:flex-row gap-5 items-start bg-white transition-all hover:-translate-y-0.5"
            >
              {/* Miniature Image with Mirror Border */}
              <div className="w-full sm:w-28 sm:h-28 h-40 shrink-0 rounded-[6px] overflow-hidden mirror-frame p-[2px]">
                <div className="mirror-frame-inner w-full h-full">
                  <img
                    src={service.image}
                    alt={service.name}
                    className="w-full h-full object-cover transition-transform duration-500 hover:scale-105"
                    loading="lazy"
                  />
                </div>
              </div>

              {/* Service Info */}
              <div className="flex-1 flex flex-col justify-between w-full h-full">
                <div>
                  <div className="flex items-start justify-between gap-3 mb-2">
                    <h3 className="font-serif-title text-lg sm:text-xl font-normal text-[#2A2C2E]">
                      {service.name}
                    </h3>
                    <span className="text-sm sm:text-base font-semibold text-[#2A2C2E] bg-[#F1F2F3] px-2.5 py-0.5 rounded-[4px] border border-[#B4B8BC]/40 whitespace-nowrap">
                      {service.price}
                    </span>
                  </div>

                  <p className="text-xs sm:text-sm text-[#5F6368] leading-relaxed mb-4">
                    {service.description}
                  </p>
                </div>

                <div className="flex items-center justify-between pt-3 border-t border-[#F1F2F3] mt-auto">
                  {service.duration ? (
                    <div className="flex items-center gap-1.5 text-xs text-[#6A6E72]">
                      <Clock className="w-3.5 h-3.5 text-[#8E9296]" />
                      <span>{service.duration}</span>
                    </div>
                  ) : (
                    <span className="text-xs text-[#8E9296]">Personalizado</span>
                  )}

                  <button
                    onClick={() => handleBookService(service)}
                    className="btn-mirror-secondary text-xs px-3.5 py-1.5 hover:bg-mirror hover:text-[#2A2C2E] transition-all flex items-center gap-1.5"
                  >
                    <MessageCircle className="w-3.5 h-3.5" />
                    <span>{services.bookButton}</span>
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Responsible Disclaimer Note */}
        <p className="text-center text-xs text-[#6A6E72] max-w-3xl mx-auto mb-10 leading-relaxed italic">
          {services.disclaimer}
        </p>

        {/* Section Main CTAs */}
        <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
          <button
            onClick={() => onBookClick()}
            className="btn-mirror-primary text-sm sm:text-base px-8 py-3.5 shadow-md w-full sm:w-auto flex items-center justify-center gap-2 cursor-pointer"
          >
            <MessageCircle className="w-5 h-5" />
            <span>{services.sectionCta} (WhatsApp)</span>
          </button>

          <a
            href="https://naielly-beauty-center.square.site/"
            target="_blank"
            rel="noopener noreferrer"
            className="btn-mirror-secondary text-sm sm:text-base px-7 py-3.5 w-full sm:w-auto flex items-center justify-center gap-2 border-[#8E9296] text-[#2A2C2E] hover:bg-white shadow-xs cursor-pointer"
          >
            <span>Agendamento Online (Square ↗)</span>
          </a>
        </div>
      </div>
    </section>
  );
};
