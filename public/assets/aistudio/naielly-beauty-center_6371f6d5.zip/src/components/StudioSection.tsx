import React, { useState } from 'react';
import {
  ShieldCheck,
  Heart,
  Cpu,
  UserCheck,
  Lock,
  Navigation,
  MapPin,
  ExternalLink,
  MessageCircle,
  CalendarCheck,
  X,
  Maximize2
} from 'lucide-react';
import { Language, StudioFeature } from '../types';
import { translations, studioPhotos, siteConfig } from '../data/siteData';

interface StudioSectionProps {
  currentLang: Language;
  onBookClick: (contextMessage?: string) => void;
}

export const StudioSection: React.FC<StudioSectionProps> = ({
  currentLang,
  onBookClick
}) => {
  const [lightboxPhotoIdx, setLightboxPhotoIdx] = useState<number | null>(null);

  const t = translations[currentLang];
  const studio = t.studio;

  // Quadruple items to ensure a seamless infinite looping track on all screen widths
  const loopingPhotos = [...studioPhotos, ...studioPhotos, ...studioPhotos, ...studioPhotos];

  const getFeatureIcon = (id: string) => {
    switch (id) {
      case 'hygiene':
        return <ShieldCheck className="w-5 h-5 text-[#6A6E72]" />;
      case 'comfort':
        return <Heart className="w-5 h-5 text-[#6A6E72]" />;
      case 'tech':
        return <Cpu className="w-5 h-5 text-[#6A6E72]" />;
      case 'privacy':
        return <Lock className="w-5 h-5 text-[#6A6E72]" />;
      case 'security':
        return <UserCheck className="w-5 h-5 text-[#6A6E72]" />;
      case 'access':
        return <Navigation className="w-5 h-5 text-[#6A6E72]" />;
      default:
        return <ShieldCheck className="w-5 h-5 text-[#6A6E72]" />;
    }
  };

  const handleStudioBooking = () => {
    let msg = '';
    if (currentLang === 'pt') {
      msg = 'Olá, Naielly! 💛 Gostaria de agendar uma visita ao studio Naielly Beauty Center na 20 Florida St!';
    } else if (currentLang === 'en') {
      msg = 'Hello Naielly! 💛 I would love to schedule a visit to Naielly Beauty Center studio at 20 Florida St!';
    } else {
      msg = '¡Hola, Naielly! 💛 ¡Me gustaría agendar una visita al studio Naielly Beauty Center en 20 Florida St!';
    }
    onBookClick(msg);
  };

  const onlineBookingLabel =
    currentLang === 'pt'
      ? 'Agendamento Online (Square)'
      : currentLang === 'en'
      ? 'Book Online (Square)'
      : 'Reservar Online (Square)';

  return (
    <section id="studio" className="py-20 md:py-28 bg-white relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Studio Logo (Center, Fine Mirror Frame) */}
        <div className="flex justify-center mb-8">
          <div className="mirror-frame p-[2px] rounded-[10px] shadow-sm max-w-[200px] sm:max-w-[220px]">
            <div className="mirror-frame-inner bg-white p-3 rounded-[8px]">
              <img
                src={siteConfig.studioLogo}
                alt="Naielly Beauty Center Logo"
                className="w-full h-auto object-contain"
                loading="lazy"
              />
            </div>
          </div>
        </div>

        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-12 sm:mb-14">
          <div className="inline-flex items-center gap-2 mb-3">
            <span className="w-8 h-px bg-[#B4B8BC]" />
            <span className="text-xs uppercase tracking-widest font-semibold text-[#6A6E72]">
              Espaço & Estrutura
            </span>
            <span className="w-8 h-px bg-[#B4B8BC]" />
          </div>
          <h2 className="font-serif-title text-2xl sm:text-3xl md:text-4xl text-[#2A2C2E] mb-4">
            {studio.title}
          </h2>
          <p className="text-sm sm:text-base text-[#5F6368] leading-relaxed">
            {studio.subtitle}
          </p>
        </div>

        {/* Infinite Continuous Sliding Carousel (No titles on photos, click to expand) */}
        <div className="relative w-full mb-16 overflow-hidden py-4">
          {/* Subtle gradient edges to fade seamlessly */}
          <div className="absolute left-0 top-0 bottom-0 w-12 sm:w-20 bg-gradient-to-r from-white to-transparent z-10 pointer-events-none" />
          <div className="absolute right-0 top-0 bottom-0 w-12 sm:w-20 bg-gradient-to-l from-white to-transparent z-10 pointer-events-none" />

          <div className="animate-infinite-scroll flex items-center gap-4 sm:gap-6">
            {loopingPhotos.map((photo, index) => (
              <div
                key={`${photo.id}-${index}`}
                onClick={() => setLightboxPhotoIdx(photo.id - 1)}
                className="w-[260px] xs:w-[300px] sm:w-[380px] shrink-0 cursor-pointer mirror-frame p-[2px] rounded-[8px] transition-transform duration-300 hover:scale-[1.02] shadow-md group"
                role="button"
                tabIndex={0}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' || e.key === ' ') {
                    e.preventDefault();
                    setLightboxPhotoIdx(photo.id - 1);
                  }
                }}
                aria-label="Expandir foto do studio"
              >
                <div className="mirror-frame-inner relative aspect-[16/10] overflow-hidden bg-[#2A2C2E] rounded-[6px]">
                  <img
                    src={photo.url}
                    alt=""
                    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                    loading="lazy"
                  />
                  {/* Subtle expand icon badge on hover */}
                  <div className="absolute inset-0 bg-black/20 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
                    <div className="p-2.5 rounded-full bg-white/90 text-[#2A2C2E] shadow-lg">
                      <Maximize2 className="w-4 h-4" />
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div className="text-center mt-3">
            <span className="text-[11px] text-[#8E9296] italic">
              Passe o mouse ou toque para pausar • Clique na foto para expandir
            </span>
          </div>
        </div>

        {/* 6 Feature Cards (Grid 3x2) */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-5 mb-14 sm:mb-16">
          {studio.features.map((feat: StudioFeature) => (
            <div
              key={feat.id}
              className="mirror-card p-4 sm:p-5 bg-white flex items-start gap-3.5 sm:gap-4 hover:-translate-y-0.5 transition-all"
            >
              <div className="p-2 sm:p-2.5 rounded-[6px] bg-[#F1F2F3] border border-[#B4B8BC]/40 shrink-0">
                {getFeatureIcon(feat.id)}
              </div>
              <div>
                <h3 className="font-serif-title text-base sm:text-lg text-[#2A2C2E] mb-1 font-medium">
                  {feat.title}
                </h3>
                <p className="text-xs sm:text-sm text-[#5F6368] leading-relaxed">
                  {feat.description}
                </p>
              </div>
            </div>
          ))}
        </div>

        {/* Location Block: Address Card + Directions Button + Google Maps Iframe */}
        <div className="bg-[#F1F2F3]/60 rounded-[8px] p-5 sm:p-8 border border-[#B4B8BC]/50 mb-12">
          <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-5 sm:gap-6 mb-6 pb-6 border-b border-[#B4B8BC]/40">
            <div>
              <div className="flex items-center gap-2 text-[#2A2C2E] mb-1">
                <MapPin className="w-5 h-5 text-[#6A6E72] shrink-0" />
                <h3 className="font-serif-title text-lg sm:text-xl text-[#2A2C2E]">
                  {studio.addressCardTitle}
                </h3>
              </div>
              <p className="text-xs sm:text-sm text-[#5F6368]">
                {siteConfig.address}
              </p>
              {siteConfig.openingHours && (
                <p className="text-xs text-[#6A6E72] mt-1">
                  Horário: {siteConfig.openingHours}
                </p>
              )}
              {siteConfig.parking && (
                <p className="text-xs text-[#6A6E72] mt-0.5">
                  Estacionamento: {siteConfig.parking}
                </p>
              )}
            </div>

            <a
              href={siteConfig.googleMapsUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="btn-mirror-secondary text-xs sm:text-sm px-4 sm:px-5 py-2.5 flex items-center gap-2 shrink-0 w-full md:w-auto justify-center"
            >
              <span>{studio.ctaDirections}</span>
              <ExternalLink className="w-3.5 h-3.5 text-[#6A6E72]" />
            </a>
          </div>

          {/* Integrated Google Maps Iframe */}
          <div className="mirror-frame p-[2px] rounded-[6px] shadow-sm">
            <div className="mirror-frame-inner w-full h-[320px] sm:h-[400px] rounded-[4px] overflow-hidden bg-white">
              <iframe
                src={siteConfig.googleMapsEmbed}
                title="Mapa de localização Naielly Beauty Center em Springfield MA"
                className="w-full h-full border-0"
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
              />
            </div>
          </div>
        </div>

        {/* Section Booking CTAs: WhatsApp + Square Online Booking */}
        <div className="flex flex-col sm:flex-row items-center justify-center gap-3.5 sm:gap-4">
          <button
            onClick={handleStudioBooking}
            className="btn-mirror-primary text-xs sm:text-base px-6 sm:px-8 py-3.5 shadow-md w-full sm:w-auto flex items-center justify-center gap-2 cursor-pointer"
          >
            <MessageCircle className="w-4 h-4 sm:w-5 sm:h-5" />
            <span>{studio.ctaBook} (WhatsApp)</span>
          </button>

          <a
            href={siteConfig.squareBookingUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="btn-mirror-secondary text-xs sm:text-base px-6 sm:px-8 py-3.5 w-full sm:w-auto flex items-center justify-center gap-2 text-[#2A2C2E] border-[#8E9296] hover:bg-white shadow-xs cursor-pointer"
          >
            <CalendarCheck className="w-4 h-4 sm:w-5 sm:h-5 text-[#2A2C2E]" />
            <span>{onlineBookingLabel}</span>
            <ExternalLink className="w-3.5 h-3.5 text-[#6A6E72]" />
          </a>
        </div>
      </div>

      {/* Lightbox for Studio Photos (CLEAN: No titles or captions as requested) */}
      {lightboxPhotoIdx !== null && (
        <div
          role="dialog"
          aria-modal="true"
          aria-label="Foto do Studio em tamanho ampliado"
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/90 backdrop-blur-md p-4 sm:p-8"
        >
          <div className="absolute top-4 right-4 z-20">
            <button
              onClick={() => setLightboxPhotoIdx(null)}
              className="p-2.5 rounded-full bg-white/10 hover:bg-white/20 text-white transition-colors cursor-pointer focus:outline-none focus:ring-2 focus:ring-white"
              aria-label="Fechar"
            >
              <X className="w-6 h-6" />
            </button>
          </div>

          <div className="max-w-4xl max-h-[85vh] flex items-center justify-center">
            <img
              src={studioPhotos[lightboxPhotoIdx].url}
              alt=""
              className="max-w-full max-h-[85vh] object-contain rounded-[4px] border border-white/20 shadow-2xl animate-fade-in"
            />
          </div>
        </div>
      )}
    </section>
  );
};
