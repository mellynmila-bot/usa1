import { siteConfig } from '../data/siteData';

export interface WhatsAppActionOptions {
  message: string;
  onSuccessToast?: (text: string) => void;
  lang?: 'pt' | 'en' | 'es';
}

const copyFeedbackMessages = {
  pt: 'Mensagem copiada! Cole na conversa.',
  en: 'Message copied! Paste it in the chat.',
  es: '¡Mensaje copiado! Pégalo en el chat.'
};

export async function openWhatsAppWithContext({
  message,
  onSuccessToast,
  lang = 'pt'
}: WhatsAppActionOptions): Promise<void> {
  const phone = siteConfig.whatsappPhone?.trim();

  if (phone) {
    const encoded = encodeURIComponent(message);
    const url = `https://wa.me/${phone}?text=${encoded}`;
    window.open(url, '_blank', 'noopener,noreferrer');
    return;
  }

  // If using direct WhatsApp link that does not support pre-filled query params:
  try {
    if (navigator?.clipboard?.writeText) {
      await navigator.clipboard.writeText(message);
    } else {
      // Fallback for older browsers / iframe restrictions
      const textarea = document.createElement('textarea');
      textarea.value = message;
      textarea.style.position = 'fixed';
      textarea.style.left = '-9999px';
      textarea.style.top = '0';
      document.body.appendChild(textarea);
      textarea.focus();
      textarea.select();
      document.execCommand('copy');
      document.body.removeChild(textarea);
    }
    
    if (onSuccessToast) {
      onSuccessToast(copyFeedbackMessages[lang]);
    }
  } catch (err) {
    console.warn('Clipboard write failed, proceeding to open link', err);
    if (onSuccessToast) {
      onSuccessToast(copyFeedbackMessages[lang]);
    }
  }

  // Open the official WhatsApp link
  window.open(siteConfig.whatsappUrl, '_blank', 'noopener,noreferrer');
}
